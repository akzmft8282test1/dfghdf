import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firestore_service.dart';

class CommentScreen extends StatefulWidget {
  final String sampleId;
  final String anonId;
  const CommentScreen(
      {super.key, required this.sampleId, required this.anonId});

  @override
  State<CommentScreen> createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen> {
  final _controller = TextEditingController();
  final _service = FirestoreService();

  void _sendComment() {
    if (_controller.text.isNotEmpty) {
      _service.addComment(widget.sampleId, _controller.text, widget.anonId);
      _controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("댓글")),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _service.getComments(widget.sampleId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snapshot.data!.docs;
                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data() as Map<String, dynamic>;
                    return ListTile(
                      title: Text(data['content']),
                      subtitle: Text("익명ID: ${data['anon_id']}"),
                    );
                  },
                );
              },
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(hintText: "댓글 입력")),
              ),
              IconButton(icon: const Icon(Icons.send), onPressed: _sendComment),
            ],
          )
        ],
      ),
    );
  }
}
