import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final _db = FirebaseFirestore.instance;
  final _uid = FirebaseAuth.instance.currentUser!.uid;

  Future<void> addComment(
      String sampleId, String content, String anonId) async {
    await _db.collection('comments').add({
      'anon_id': anonId,
      'sample_id': sampleId,
      'content': content,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  Future<void> addLike(String sampleId, String anonId) async {
    await _db.collection('likes').add({
      'anon_id': anonId,
      'sample_id': sampleId,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot> getComments(String sampleId) {
    return _db
        .collection('comments')
        .where('sample_id', isEqualTo: sampleId)
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot> getLikes(String sampleId) {
    return _db
        .collection('likes')
        .where('sample_id', isEqualTo: sampleId)
        .snapshots();
  }
}
