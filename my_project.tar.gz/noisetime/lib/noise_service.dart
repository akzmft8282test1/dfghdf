import 'package:noise_meter/noise_meter.dart';
import 'dart:async';

class NoiseService {
  final NoiseMeter _noiseMeter = NoiseMeter();
  StreamSubscription<NoiseReading>? _subscription;

  void startListening(Function(double dbValue) onData) {
    _subscription = _noiseMeter.noiseStream.listen((NoiseReading reading) {
      // 평균 dB 값 사용
      double db = reading.meanDecibel;
      onData(db);
    });
  }

  void stopListening() {
    _subscription?.cancel();
    _subscription = null;
  }
}
