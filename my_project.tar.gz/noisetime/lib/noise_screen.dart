import 'package:flutter/material.dart';
import 'noise_service.dart';
import 'noise_chart.dart';
import 'notification_service.dart';
import 'firestore_service.dart';

class NoiseScreen extends StatefulWidget {
  const NoiseScreen({super.key});

  @override
  State<NoiseScreen> createState() => _NoiseScreenState();
}

class NoiseAlertScreen extends StatefulWidget {
  const NoiseAlertScreen({super.key});

  @override
  State<NoiseAlertScreen> createState() => _NoiseAlertScreenState();
}


class _NoiseAlertScreenState extends State<NoiseAlertScreen> {
  final _noiseService = NoiseService();
  double? _currentDb;
  double threshold = 70.0; // 기본 기준치 (예: 70dB)

  @override
  void initState() {
    super.initState();
    _noiseService.startListening((dbValue) {
      setState(() => _currentDb = dbValue);

      if (dbValue > threshold) {
        NotificationService.showAlert("현재 소음 ${dbValue.toStringAsFixed(1)} dB (기준치 초과!)");
      }
    });
  }

  @override
  void dispose() {
    _noiseService.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("소음 알림")),
      body: Column(
        children: [
          Text("현재 소음: ${_currentDb?.toStringAsFixed(1) ?? '--'} dB"),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text("기준치: "),
              SizedBox(
                width: 80,
                child: TextField(
                  keyboardType: TextInputType.number,
                  onSubmitted: (value) {
                    setState(() => threshold = double.tryParse(value) ?? threshold);
                  },
                  decoration: InputDecoration(hintText: threshold.toString()),
                ),
              ),
              const Text(" dB"),
            ],
          ),
        ],
      ),
    );
  }
}

class _NoiseScreenState extends State<NoiseScreen> {
  final _noiseService = NoiseService();
  double? _currentDb;

  @override
  void initState() {
    super.initState();
    _noiseService.startListening((dbValue) {
      setState(() {
        _currentDb = dbValue;
      });
      // 예시: Firestore에 저장
      saveNoiseSample(dbValue, "anon-uuid", "group-123");
    });
  }

  @override
  void dispose() {
    _noiseService.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("소음 측정기 & 그래프")),
      body: Column(
        children: const [
          Expanded(
            flex: 1,
            child: Center(child: Text("실시간 소음 측정 중...")),
          ),
          Expanded(
            flex: 2,
            child: NoiseChart(),
          ),
        ],
      ),
    );
  }
}
