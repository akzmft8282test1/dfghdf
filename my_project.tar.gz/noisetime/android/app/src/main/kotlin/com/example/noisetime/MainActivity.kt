package com.example.noisetime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
