import os
import json
import csv
import xml.etree.ElementTree as ET
from pathlib import Path
import mimetypes
from datetime import datetime
import html

class ProjectScanner:
    def __init__(self, root_dir='.'):
        self.root_dir = root_dir
        self.project_name = os.path.basename(os.path.abspath(root_dir))
        self.script_name = os.path.basename(__file__)  # 현재 스크립트 파일명
        
    def scan_project(self, include_binary=False, specific_folders=None, exclude_folders=None, max_preview_size=100000):
        """프로젝트 스캔"""
        if specific_folders is None:
            specific_folders = []
        if exclude_folders is None:
            exclude_folders = []
            
        # 기본 무시 목록 + 사용자 지정 제외 폴더
        ignore_dirs = {'.git', '__pycache__', '.next', '.nuxt', 'dist', 'build', '.expo'}
        ignore_dirs.update(exclude_folders)  # 사용자 지정 제외 폴더 추가
        
        ignore_files = {'.DS_Store', 'thumbs.db', self.script_name}  # 자기 자신 제외
        
        # 특정 폴더가 지정된 경우 해당 폴더는 무시하지 않음
        for folder in specific_folders:
            if folder in ignore_dirs:
                ignore_dirs.remove(folder)
        
        structure = {
            "project_info": {
                "name": self.project_name,
                "absolute_path": os.path.abspath(self.root_dir),
                "scan_date": datetime.now().isoformat(),
                "total_size": 0,
                "file_count": 0,
                "directory_count": 0,
                "excluded_files": [self.script_name],
                "scan_settings": {
                    "include_binary": include_binary,
                    "specific_folders": specific_folders,
                    "exclude_folders": exclude_folders,
                    "max_preview_size": max_preview_size
                }
            },
            "directory_tree": "",
            "files": {},
            "file_metadata": {},
            "statistics": {
                "by_extension": {},
                "by_type": {"text": 0, "binary": 0},
                "size_distribution": {}
            }
        }
        
        def build_tree(current_dir, prefix="", is_last=True, level=0):
            lines = []
            dir_name = os.path.basename(current_dir) if current_dir != self.root_dir else self.project_name
            
            if current_dir == self.root_dir:
                lines.append(f"{dir_name}/")
            else:
                connector = "└── " if is_last else "├── "
                lines.append(f"{prefix}{connector}{dir_name}/")
            
            new_prefix = prefix + ("    " if is_last else "│   ")
            
            try:
                items = []
                for item in sorted(os.listdir(current_dir)):
                    if item in ignore_files:
                        continue
                    item_path = os.path.join(current_dir, item)
                    if os.path.isdir(item_path) and item in ignore_dirs and item not in specific_folders:
                        continue
                    items.append(item)
                
                dirs = [item for item in items if os.path.isdir(os.path.join(current_dir, item))]
                files = [item for item in items if os.path.isfile(os.path.join(current_dir, item))]
                
                sorted_items = sorted(dirs) + sorted(files)
                
                for i, item in enumerate(sorted_items):
                    item_path = os.path.join(current_dir, item)
                    is_last_item = (i == len(sorted_items) - 1)
                    
                    if os.path.isdir(item_path):
                        structure["project_info"]["directory_count"] += 1
                        sub_lines = build_tree(item_path, new_prefix, is_last_item, level + 1)
                        lines.extend(sub_lines)
                    else:
                        connector = "└── " if is_last_item else "├── "
                        lines.append(f"{new_prefix}{connector}{item}")
                        
                        relative_path = os.path.relpath(item_path, self.root_dir)
                        file_info = self.read_file_content(item_path, include_binary, max_preview_size)
                        
                        if file_info["content"] is not None:  # 바이너리 파일이 아닌 경우만
                            structure["files"][relative_path] = file_info["content"]
                            structure["file_metadata"][relative_path] = {
                                "size": file_info["size"],
                                "type": file_info["type"],
                                "extension": file_info["extension"],
                                "mime_type": file_info["mime_type"],
                                "is_binary": file_info["is_binary"],
                                "line_count": file_info["line_count"]
                            }
                            
                            structure["project_info"]["file_count"] += 1
                            structure["project_info"]["total_size"] += file_info["size"]
                            
                            ext = file_info["extension"] if file_info["extension"] else "no_extension"
                            if ext not in structure["statistics"]["by_extension"]:
                                structure["statistics"]["by_extension"][ext] = 0
                            structure["statistics"]["by_extension"][ext] += 1
                            
                            if file_info["is_binary"]:
                                structure["statistics"]["by_type"]["binary"] += 1
                            else:
                                structure["statistics"]["by_type"]["text"] += 1
                            
                            size_kb = file_info["size"] / 1024
                            size_range = self.get_size_range(size_kb)
                            if size_range not in structure["statistics"]["size_distribution"]:
                                structure["statistics"]["size_distribution"][size_range] = 0
                            structure["statistics"]["size_distribution"][size_range] += 1
            
            except PermissionError:
                lines.append(f"{new_prefix}└── [Permission Denied]")
            except Exception as e:
                lines.append(f"{new_prefix}└── [Error: {str(e)}]")
            
            return lines
        
        structure["directory_tree"] = "\n".join(build_tree(self.root_dir))
        return structure
    
    def read_file_content(self, file_path, include_binary, max_preview_size):
        """파일 내용 읽기"""
        try:
            file_size = os.path.getsize(file_path)
            mime_type, _ = mimetypes.guess_type(file_path)
            file_ext = Path(file_path).suffix.lower()
            
            # 텍스트 파일 확장자
            text_extensions = {'.txt', '.py', '.js', '.jsx', '.ts', '.tsx', '.json', '.html', 
                             '.css', '.md', '.xml', '.yml', '.yaml', '.java', '.c', '.cpp', 
                             '.h', '.hh', '.hpp', '.php', '.rb', '.go', '.rs', '.swift', 
                             '.kt', '.dart', '.vue', '.svelte', '.scala', '.r', '.m', '.sql',
                             '.sh', '.bash', '.zsh', '.ps1', '.bat', '.cmd', '.fish',
                             '.config', '.gitignore', '.eslintrc', '.prettierrc'}
            
            is_binary = file_ext not in text_extensions
            
            # 바이너리 파일이고 포함하지 않기로 했으면 None 반환
            if is_binary and not include_binary:
                return {
                    "content": None,
                    "size": file_size,
                    "type": "binary_excluded",
                    "extension": file_ext,
                    "mime_type": mime_type,
                    "is_binary": True,
                    "line_count": 0
                }
            
            if is_binary:
                # 바이너리 파일인 경우 간단한 정보만
                content = f"[Binary File: {mime_type or 'unknown type'}, Size: {file_size} bytes]"
                line_count = 0
            else:
                # 텍스트 파일인 경우 전체 내용 읽기
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        line_count = content.count('\n') + 1
                except UnicodeDecodeError:
                    # UTF-8 실패 시 다른 인코딩 시도
                    try:
                        with open(file_path, 'r', encoding='latin-1') as f:
                            content = f.read()
                            line_count = content.count('\n') + 1
                    except Exception as e:
                        content = f"[Error reading file with any encoding: {str(e)}]"
                        line_count = 0
                
                # 매우 큰 텍스트 파일도 그대로 유지
                if len(content) > max_preview_size:
                    print(f"⚠️  Large text file: {file_path} ({len(content)} characters)")
            
            return {
                "content": content,
                "size": file_size,
                "type": "binary" if is_binary else "text",
                "extension": file_ext,
                "mime_type": mime_type,
                "is_binary": is_binary,
                "line_count": line_count
            }
                
        except Exception as e:
            return {
                "content": f"[Error reading file: {str(e)}]",
                "size": 0,
                "type": "error",
                "extension": "",
                "mime_type": None,
                "is_binary": False,
                "line_count": 0
            }
    
    def get_size_range(self, size_kb):
        """크기 범위 반환"""
        if size_kb < 1:
            return "0-1KB"
        elif size_kb < 10:
            return "1-10KB"
        elif size_kb < 100:
            return "10-100KB"
        elif size_kb < 1024:
            return "100KB-1MB"
        elif size_kb < 10240:
            return "1-10MB"
        else:
            return "10MB+"

class OutputFormatter:
    """다양한 형식으로 출력하는 클래스"""
    
    @staticmethod
    def to_json(structure, output_file):
        """JSON 형식으로 저장"""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(structure, f, ensure_ascii=False, indent=2)
        print(f"✅ JSON 저장 완료: {output_file}")
    
    @staticmethod
    def to_markdown(structure, output_file):
        """마크다운 형식으로 저장"""
        settings = structure['project_info']['scan_settings']
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"# {structure['project_info']['name']} 프로젝트 구조\n\n")
            
            f.write("## 프로젝트 정보\n\n")
            f.write(f"- **스캔 일시**: {structure['project_info']['scan_date']}\n")
            f.write(f"- **경로**: {structure['project_info']['absolute_path']}\n")
            f.write(f"- **파일 수**: {structure['project_info']['file_count']}개\n")
            f.write(f"- **디렉토리 수**: {structure['project_info']['directory_count']}개\n")
            f.write(f"- **총 크기**: {structure['project_info']['total_size'] / 1024 / 1024:.2f}MB\n")
            f.write(f"- **제외된 파일**: {', '.join(structure['project_info']['excluded_files'])}\n")
            
            f.write("\n## 스캔 설정\n\n")
            f.write(f"- **바이너리 파일 포함**: {'예' if settings['include_binary'] else '아니오'}\n")
            f.write(f"- **특정 폴더**: {', '.join(settings['specific_folders']) if settings['specific_folders'] else '없음'}\n")
            f.write(f"- **제외 폴더**: {', '.join(settings['exclude_folders']) if settings['exclude_folders'] else '없음'}\n")
            f.write(f"- **최대 미리보기 크기**: {settings['max_preview_size']} characters\n")
            
            f.write("\n## 통계\n\n")
            f.write(f"- **텍스트 파일**: {structure['statistics']['by_type']['text']}개\n")
            if structure['statistics']['by_type']['binary'] > 0:
                f.write(f"- **바이너리 파일**: {structure['statistics']['by_type']['binary']}개\n")
            
            f.write("\n## 디렉토리 구조\n\n```\n")
            f.write(structure['directory_tree'])
            f.write("\n```\n\n")
            
            f.write("## 파일 내용\n\n")
            for file_path, content in structure['files'].items():
                metadata = structure['file_metadata'][file_path]
                f.write(f"### {file_path}\n\n")
                f.write(f"**크기**: {metadata['size']} bytes | **라인 수**: {metadata['line_count']} | **타입**: {metadata['type']}\n\n")
                f.write("```\n")
                f.write(content)
                f.write("\n```\n\n")
        
        print(f"✅ Markdown 저장 완료: {output_file}")
    
    @staticmethod
    def to_csv(structure, output_file):
        """CSV 형식으로 저장"""
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['File Path', 'Size (bytes)', 'Type', 'Extension', 'Line Count', 'Content Preview'])
            
            for file_path, metadata in structure['file_metadata'].items():
                content = structure['files'].get(file_path, '')
                preview = content[:100] + "..." if len(content) > 100 else content
                writer.writerow([
                    file_path,
                    metadata['size'],
                    metadata['type'],
                    metadata['extension'],
                    metadata['line_count'],
                    preview.replace('\n', '\\n').replace('\r', '\\r')
                ])
        
        print(f"✅ CSV 저장 완료: {output_file}")
    
    @staticmethod
    def to_xml(structure, output_file):
        """XML 형식으로 저장"""
        root = ET.Element("project")
        
        # 프로젝트 정보
        info = ET.SubElement(root, "info")
        for key, value in structure['project_info'].items():
            if key == 'excluded_files':
                excluded_elem = ET.SubElement(info, key)
                for file in value:
                    ET.SubElement(excluded_elem, "file").text = file
            elif key == 'scan_settings':
                settings_elem = ET.SubElement(info, key)
                for setting_key, setting_value in value.items():
                    if isinstance(setting_value, list):
                        list_elem = ET.SubElement(settings_elem, setting_key)
                        for item in setting_value:
                            ET.SubElement(list_elem, "item").text = str(item)
                    else:
                        ET.SubElement(settings_elem, setting_key).text = str(setting_value)
            else:
                ET.SubElement(info, key).text = str(value)
        
        # 통계
        stats = ET.SubElement(root, "statistics")
        for category, values in structure['statistics'].items():
            category_elem = ET.SubElement(stats, category)
            if isinstance(values, dict):
                for key, value in values.items():
                    ET.SubElement(category_elem, key).text = str(value)
            else:
                category_elem.text = str(values)
        
        # 디렉토리 트리
        ET.SubElement(root, "directory_tree").text = structure['directory_tree']
        
        # 파일들
        files_elem = ET.SubElement(root, "files")
        for file_path, content in structure['files'].items():
            file_elem = ET.SubElement(files_elem, "file")
            ET.SubElement(file_elem, "path").text = file_path
            ET.SubElement(file_elem, "content").text = str(content)
            
            metadata = structure['file_metadata'][file_path]
            for key, value in metadata.items():
                ET.SubElement(file_elem, key).text = str(value)
        
        tree = ET.ElementTree(root)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            tree.write(f, encoding='unicode')
        print(f"✅ XML 저장 완료: {output_file}")
    
    @staticmethod
    def to_text(structure, output_file):
        """간단한 텍스트 형식으로 저장"""
        settings = structure['project_info']['scan_settings']
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"프로젝트: {structure['project_info']['name']}\n")
            f.write(f"스캔 일시: {structure['project_info']['scan_date']}\n")
            f.write(f"경로: {structure['project_info']['absolute_path']}\n")
            f.write(f"파일 수: {structure['project_info']['file_count']}\n")
            f.write(f"디렉토리 수: {structure['project_info']['directory_count']}\n")
            f.write(f"총 크기: {structure['project_info']['total_size'] / 1024 / 1024:.2f}MB\n")
            f.write(f"텍스트 파일: {structure['statistics']['by_type']['text']}개\n")
            if structure['statistics']['by_type']['binary'] > 0:
                f.write(f"바이너리 파일: {structure['statistics']['by_type']['binary']}개\n")
            f.write(f"제외된 파일: {', '.join(structure['project_info']['excluded_files'])}\n")
            
            f.write("\n스캔 설정:\n")
            f.write(f"  바이너리 파일 포함: {'예' if settings['include_binary'] else '아니오'}\n")
            f.write(f"  특정 폴더: {', '.join(settings['specific_folders']) if settings['specific_folders'] else '없음'}\n")
            f.write(f"  제외 폴더: {', '.join(settings['exclude_folders']) if settings['exclude_folders'] else '없음'}\n")
            f.write(f"  최대 미리보기 크기: {settings['max_preview_size']} characters\n")
            
            f.write("\n" + "="*80 + "\n")
            f.write("디렉토리 구조:\n")
            f.write("="*80 + "\n")
            f.write(structure['directory_tree'])
            f.write("\n\n" + "="*80 + "\n")
            f.write("파일 내용:\n")
            f.write("="*80 + "\n")
            
            for file_path, content in structure['files'].items():
                metadata = structure['file_metadata'][file_path]
                f.write(f"\n[{file_path}]\n")
                f.write(f"크기: {metadata['size']} bytes | 라인 수: {metadata['line_count']} | 타입: {metadata['type']}\n")
                f.write("-" * 80 + "\n")
                f.write(content)
                f.write("\n" + "="*80 + "\n")
        
        print(f"✅ Text 저장 완료: {output_file}")
    
    @staticmethod
    def to_html(structure, output_file):
        """HTML 형식으로 저장"""
        settings = structure['project_info']['scan_settings']
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Structure: """ + structure['project_info']['name'] + """</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            text-align: center;
        }
        .header h1 {
            color: #2c3e50;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .header .subtitle {
            color: #7f8c8d;
            font-size: 1.1em;
        }
        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card h2 {
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 1.5em;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .info-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #3498db;
        }
        .info-item strong {
            color: #2c3e50;
            display: block;
            margin-bottom: 5px;
        }
        .settings-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .setting-item {
            background: #e8f4fd;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #3498db;
        }
        .excluded-info {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            border-radius: 10px;
            margin-top: 15px;
        }
        .tree {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
            border-radius: 10px;
            font-family: 'Courier New', monospace;
            white-space: pre;
            overflow-x: auto;
            font-size: 0.9em;
            line-height: 1.4;
        }
        .file-section {
            margin-top: 30px;
        }
        .file-item {
            background: white;
            border: 1px solid #e1e8ed;
            border-radius: 10px;
            margin-bottom: 20px;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .file-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .file-header {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .file-header:hover {
            background: linear-gradient(135deg, #2980b9, #2573a7);
        }
        .file-path {
            font-weight: bold;
            font-size: 1.1em;
        }
        .file-meta {
            font-size: 0.9em;
            opacity: 0.9;
        }
        .file-content {
            padding: 0;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
            background: #f8f9fa;
        }
        .file-content.expanded {
            max-height: 1000px;
            padding: 20px;
        }
        .code-block {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            white-space: pre-wrap;
            overflow-x: auto;
            font-size: 0.9em;
            line-height: 1.4;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        .stat-item {
            background: linear-gradient(135deg, #74b9ff, #0984e3);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            display: block;
        }
        .stat-label {
            font-size: 0.9em;
            opacity: 0.9;
        }
        .toggle-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.8em;
        }
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            .header h1 {
                font-size: 2em;
            }
            .info-grid, .settings-grid {
                grid-template-columns: 1fr;
            }
            .file-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎵 """ + structure['project_info']['name'] + """</h1>
            <div class="subtitle">프로젝트 구조 분석 리포트</div>
        </div>
        
        <div class="card">
            <h2>📊 프로젝트 정보</h2>
            <div class="info-grid">
                <div class="info-item">
                    <strong>스캔 일시</strong>
                    <span>""" + structure['project_info']['scan_date'] + """</span>
                </div>
                <div class="info-item">
                    <strong>프로젝트 경로</strong>
                    <span>""" + structure['project_info']['absolute_path'] + """</span>
                </div>
                <div class="info-item">
                    <strong>총 파일 수</strong>
                    <span>""" + str(structure['project_info']['file_count']) + """개</span>
                </div>
                <div class="info-item">
                    <strong>디렉토리 수</strong>
                    <span>""" + str(structure['project_info']['directory_count']) + """개</span>
                </div>
            </div>
            
            <div class="stats-grid">
                <div class="stat-item">
                    <span class="stat-number">""" + str(structure['project_info']['file_count']) + """</span>
                    <span class="stat-label">전체 파일</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">""" + str(structure['statistics']['by_type']['text']) + """</span>
                    <span class="stat-label">텍스트 파일</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">""" + f"{structure['project_info']['total_size'] / 1024 / 1024:.1f}" + """</span>
                    <span class="stat-label">총 크기 (MB)</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">""" + str(len(structure['statistics']['by_extension'])) + """</span>
                    <span class="stat-label">파일 확장자</span>
                </div>
            </div>
            
            <div class="settings-grid">
                <div class="setting-item">
                    <strong>🔧 스캔 설정</strong><br>
                    바이너리 파일: <strong>""" + ('포함' if settings['include_binary'] else '제외') + """</strong><br>
                    최대 미리보기: <strong>""" + str(settings['max_preview_size']) + """ characters</strong>
                </div>
                <div class="setting-item">
                    <strong>📁 특정 폴더</strong><br>
                    """ + (', '.join(settings['specific_folders']) if settings['specific_folders'] else '없음') + """
                </div>
                <div class="setting-item">
                    <strong>🚫 제외 폴더</strong><br>
                    """ + (', '.join(settings['exclude_folders']) if settings['exclude_folders'] else '없음') + """
                </div>
            </div>
            
            <div class="excluded-info">
                <strong>📝 참고사항</strong><br>
                분석 스크립트 파일('"""+ structure['project_info']['excluded_files'][0] +"""')은 제외되었습니다.
            </div>
        </div>
        
        <div class="card">
            <h2>🌳 디렉토리 구조</h2>
            <div class="tree">""" + structure['directory_tree'] + """</div>
        </div>
        
        <div class="card file-section">
            <h2>📄 파일 내용</h2>
            <div id="file-list">""")
            
            for file_path, content in structure['files'].items():
                metadata = structure['file_metadata'][file_path]
                escaped_content = html.escape(content)
                f.write(f"""
                <div class="file-item">
                    <div class="file-header" onclick="toggleContent('{file_path.replace('/', '_')}')">
                        <div>
                            <div class="file-path">{file_path}</div>
                            <div class="file-meta">
                                크기: {metadata['size']} bytes | 
                                라인 수: {metadata['line_count']} | 
                                타입: {metadata['type']} | 
                                확장자: {metadata['extension']}
                            </div>
                        </div>
                        <button class="toggle-btn" id="btn_{file_path.replace('/', '_')}">열기</button>
                    </div>
                    <div class="file-content" id="content_{file_path.replace('/', '_')}">
                        <div class="code-block">{escaped_content}</div>
                    </div>
                </div>""")
            
            f.write("""
            </div>
        </div>
    </div>

    <script>
        function toggleContent(fileId) {
            const content = document.getElementById('content_' + fileId);
            const button = document.getElementById('btn_' + fileId);
            
            if (content.classList.contains('expanded')) {
                content.classList.remove('expanded');
                button.textContent = '열기';
            } else {
                content.classList.add('expanded');
                button.textContent = '닫기';
            }
        }
        
        // 첫 번째 파일 자동으로 열기
        document.addEventListener('DOMContentLoaded', function() {
            const firstFile = document.querySelector('.file-item');
            if (firstFile) {
                const firstHeader = firstFile.querySelector('.file-header');
                firstHeader.click();
            }
        });
    </script>
</body>
</html>""")
        print(f"✅ HTML 저장 완료: {output_file}")

def parse_folder_input(input_str):
    """폴더 입력을 파싱하는 함수"""
    if not input_str.strip():
        return []
    
    folders = []
    for folder in input_str.split(','):
        folder = folder.strip()
        if folder:
            # 경로 정규화
            folder = folder.rstrip('/\\')
            folders.append(folder)
    
    return folders

def main():
    print("🎵 NoiseTime 프로젝트 구조 분석기 (다중 형식 지원)")
    print("=" * 60)
    
    # 현재 스크립트 파일명 출력
    script_name = os.path.basename(__file__)
    print(f"📝 현재 스크립트: {script_name} (자동 제외)")
    
    # 설정 옵션
    include_binary = input("바이너리 파일을 포함하시겠습니까? (y/n, 기본 n): ").lower().strip() == 'y'
    
    # 특정 폴더 지정
    print("\n📁 특정 폴더 설정:")
    print("   (스캔할 폴더를 쉼표로 구분하여 입력, 예: src,assets,components)")
    specific_folders_input = input("스캔할 특정 폴더: ").strip()
    specific_folders = parse_folder_input(specific_folders_input)
    
    # 제외 폴더 지정
    print("\n🚫 제외 폴더 설정:")
    print("   (제외할 폴더를 쉼표로 구분하여 입력, 예: temp,logs,backup)")
    print("   기본 제외: .git, __pycache__, node_modules, dist, build 등")
    exclude_folders_input = input("추가로 제외할 폴더: ").strip()
    exclude_folders = parse_folder_input(exclude_folders_input)
    
    # 출력 형식 선택
    print("\n📁 출력 형식을 선택하세요:")
    print("1. JSON")
    print("2. Markdown")
    print("3. CSV")
    print("4. XML")
    print("5. Text")
    print("6. HTML")
    print("7. 모든 형식")
    
    format_choice = input("선택 (1-7, 기본 1): ").strip() or "1"
    
    # 프로젝트 스캔
    scanner = ProjectScanner()
    print("\n🔍 프로젝트 스캔 중...")
    structure = scanner.scan_project(
        include_binary=include_binary,
        specific_folders=specific_folders,
        exclude_folders=exclude_folders,
        max_preview_size=500000
    )
    
    # 기본 파일명
    base_name = f"{scanner.project_name}_structure"
    
    # 형식별 저장
    formatter = OutputFormatter()
    
    if format_choice == "1" or format_choice == "7":
        formatter.to_json(structure, f"{base_name}.json")
    if format_choice == "2" or format_choice == "7":
        formatter.to_markdown(structure, f"{base_name}.md")
    if format_choice == "3" or format_choice == "7":
        formatter.to_csv(structure, f"{base_name}.csv")
    if format_choice == "4" or format_choice == "7":
        formatter.to_xml(structure, f"{base_name}.xml")
    if format_choice == "5" or format_choice == "7":
        formatter.to_text(structure, f"{base_name}.txt")
    if format_choice == "6" or format_choice == "7":
        formatter.to_html(structure, f"{base_name}.html")
    
    # 통계 출력
    settings = structure['project_info']['scan_settings']
    print(f"\n📊 스캔 완료!")
    print(f"   📁 디렉토리: {structure['project_info']['directory_count']}개")
    print(f"   📄 파일: {structure['project_info']['file_count']}개")
    print(f"   💾 총 크기: {structure['project_info']['total_size'] / 1024 / 1024:.2f}MB")
    print(f"   📝 텍스트 파일: {structure['statistics']['by_type']['text']}개")
    if include_binary:
        print(f"   🖼️  바이너리 파일: {structure['statistics']['by_type']['binary']}개")
    print(f"   🚫 제외된 파일: {script_name}")
    if specific_folders:
        print(f"   📂 특정 폴더: {', '.join(specific_folders)}")
    if exclude_folders:
        print(f"   🚫 제외 폴더: {', '.join(exclude_folders)}")

if __name__ == "__main__":
    main()